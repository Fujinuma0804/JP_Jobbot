
    var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "210.138.37.191",
                port: parseInt("6010")
            },
            bypassList: ["localhost"]
        }
    };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "tb32i12hnsdd",
                    password: "FfTheKHwMVgPIAtq"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    